### Как запустить проект:


- Doggram.

- ## Установка
    > 1. Склонировать репозиторий
    > 2. Создать и активировать venv    
        >` python -m venv venv `\
        >` source venv/script/activate `
    > 3. Установка зависимости\
        >` pip install -r requirements.txt `
    > 4. Сделать миграции\
        >` python manage.py makemigrations python manage.py migrate`
    > 5. Запуск\
        >` python manage.py runserver`

